-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 12, 2021 at 02:27 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `2111_tafifo`
--

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `id_transaction` int(11) NOT NULL,
  `kode_transaction` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `start_service` datetime NOT NULL,
  `end_service` varchar(30) DEFAULT NULL,
  `status` varchar(20) NOT NULL,
  `id_employee` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`id_transaction`, `kode_transaction`, `name`, `type`, `start_service`, `end_service`, `status`, `id_employee`) VALUES
(1, 'TR101', 'Dwi Nuca', 'Teller', '2021-01-11 07:05:00', '2021-01-11 07:10:00', 'done', 1),
(2, 'TR102', 'Nur Ikhwan', 'Teller', '2021-01-11 07:11:00', '2021-01-11 07:15:00', 'done', 1),
(3, 'TR103', 'Suryajana', 'Teller', '2021-01-11 07:20:00', '2021-01-11 07:25:00 ', 'done', 1),
(4, 'TR104', 'Bella Laura', 'Teller', '2021-01-11 07:30:00', '2021-01-11 07:35:00 ', 'done', 1),
(5, 'TR105', 'Tia Mulia', 'Teller', '2021-01-11 07:50:00', '2021-01-11 07:52:00', 'done', 1),
(6, 'TR106', 'Riza Rias', 'Teller', '2021-01-11 07:56:00', '2021-01-11 07:59:00', 'done', 1),
(7, 'TR107', 'Novita Mei', 'Teller', '2021-01-11 08:10:00', '2021-01-11 08:15:00', 'done', 1),
(8, 'TR108', 'Lailatul', 'Teller', '2021-01-11 08:20:00', '2021-01-11 08:25:00', 'done', 1),
(9, 'TR109', 'Miftakhul', 'Teller', '2021-01-11 08:28:00', '2021-01-11 08:30:00', 'done', 1),
(10, 'TR1010', 'Adiar', 'Teller', '2021-01-11 08:52:00', '2021-01-11 08:59:00', 'done', 1),
(11, 'TR1010', 'Rey', 'Teller', '2021-01-11 09:02:00', '2021-01-11 09:20:00', 'done', 1),
(12, 'TR1010', 'Sinta', 'Teller', '2021-01-11 09:48:00', '2021-01-11 09:59:00', 'done', 1),
(13, 'TR1010', 'Nana', 'Teller', '2021-01-11 10:10:00', '2021-01-11 10:14:00', 'done', 1),
(14, 'TR1010', 'Lin Luna', 'Teller', '2021-01-11 10:24:00', '2021-01-11 10:40:00', 'done', 1),
(15, 'TR1010', 'Jannah Jumatul', 'Teller', '2021-01-11 10:41:00', '2021-01-11 10:50:00', 'done', 1),
(16, 'TR1010', 'Coronavira', 'Teller', '2021-01-11 10:52:00', '2021-01-11 10:59:00', 'done', 1),
(17, 'TR1010', 'Vierranatasya', 'Teller', '2021-01-11 11:02:00', '2021-01-11 11:05:00', 'done', 1),
(18, 'TR1010', 'Adeeva Salsa', 'Teller', '2021-01-11 11:10:00', '2021-01-11 11:15:00', 'done', 1),
(19, 'TR1010', 'Alifah Salsabila', 'Teller', '2021-01-11 11:18:00', '2021-01-11 11:24:00', 'done', 1),
(20, 'TR1010', 'Cahya Eka', 'Teller', '2021-01-11 11:32:00', '2021-01-11 11:49:00', 'done', 1),
(21, 'TR1010', 'Dwi Nur Cahyo', 'Teller', '2021-01-11 11:50:00', '2021-01-11 11:59:00', 'done', 1),
(22, 'TR1010', 'Alysa Saufika Ananda', 'Teller', '2021-01-11 12:04:00', '2021-01-11 12:10:00', 'done', 1),
(23, 'TR1010', 'Nefa Maulidiah', 'Teller', '2021-01-11 12:15:00', '2021-01-11 12:20:00', 'done', 1),
(24, 'TR1010', 'Tini Ariantini', 'Teller', '2021-01-11 12:25:00', '2021-01-11 12:34:00', 'done', 1),
(25, 'TR1010', 'Ely Nur Rahayu', 'Teller', '2021-01-11 12:40:00', '2021-01-11 12:45:00', 'done', 1),
(26, 'TR1010', 'Ananda Bella Oktavia', 'Teller', '2021-01-11 12:52:00', '2021-01-11 12:59:00', 'done', 1),
(27, 'TR1010', 'Alysa Fira', 'Teller', '2021-01-11 13:30:00', '2021-01-11 13:40:00', 'done', 1),
(28, 'TR1010', 'Tiana Nur Ikhmah', 'Teller', '2021-01-11 13:52:00', '2021-01-11 13:59:00', 'done', 1),
(29, 'TR1010', 'Supriman Andi', 'Teller', '2021-01-11 14:20:00', '2021-01-11 14:29:00', 'done', 1),
(30, 'TR1010', 'Risa ronatika', 'Teller', '2021-01-11 14:30:00', '2021-01-11 14:39:00', 'done', 1),
(31, 'TR1010', 'Umbu anwar', 'Teller', '2021-01-11 14:54:00', '2021-01-11 14:59:00', 'done', 1),
(32, 'TR1010', 'Alysa Saufika Ananda', 'Teller', '2021-01-11 15:02:00', '2021-01-11 15:23:00', 'done', 1),
(33, 'TR101', 'Dwi Nuca', 'Teller', '2021-01-10 07:05:00', '2021-01-10 07:10:00', 'done', 1),
(34, 'TR102', 'Nur Ikhwan', 'Teller', '2021-01-10 07:11:00', '2021-01-10 07:15:00', 'done', 1),
(35, 'TR103', 'Suryajana', 'Teller', '2021-01-10 07:20:00', '2021-01-10 07:25:00 ', 'done', 1),
(36, 'TR104', 'Bella Laura', 'Teller', '2021-01-10 07:30:00', '2021-01-10 07:35:00 ', 'done', 1),
(37, 'TR105', 'Tia Mulia', 'Teller', '2021-01-10 07:50:00', '2021-01-10 07:52:00', 'done', 1),
(38, 'TR106', 'Riza Rias', 'Teller', '2021-01-10 07:56:00', '2021-01-10 07:59:00', 'done', 1),
(39, 'TR107', 'Novita Mei', 'Teller', '2021-01-10 08:10:00', '2021-01-10 08:15:00', 'done', 1),
(40, 'TR108', 'Lailatul', 'Teller', '2021-01-10 08:20:00', '2021-01-10 08:25:00', 'done', 1),
(41, 'TR109', 'Miftakhul', 'Teller', '2021-01-10 08:28:00', '2021-01-10 08:30:00', 'done', 1),
(42, 'TR1010', 'Adiar', 'Teller', '2021-01-10 08:52:00', '2021-01-10 08:59:00', 'done', 1),
(43, 'TR1010', 'Rey', 'Teller', '2021-01-10 09:02:00', '2021-01-10 09:20:00', 'done', 1),
(44, 'TR1010', 'Sinta', 'Teller', '2021-01-10 09:48:00', '2021-01-10 09:59:00', 'done', 1),
(45, 'TR1010', 'Nana', 'Teller', '2021-01-10 10:10:00', '2021-01-10 10:14:00', 'done', 1),
(46, 'TR101', 'Dwi Nuca', 'Teller', '2021-01-04 07:05:00', '2021-01-04 07:10:00', 'done', 1),
(47, 'TR102', 'Nur Ikhwan', 'Teller', '2021-01-04 07:11:00', '2021-01-04 07:15:00', 'done', 1),
(48, 'TR103', 'Suryajana', 'Teller', '2021-01-04 07:20:00', '2021-01-04 07:25:00 ', 'done', 1),
(49, 'TR104', 'Bella Laura', 'Teller', '2021-01-04 07:30:00', '2021-01-04 07:35:00 ', 'done', 1),
(50, 'TR105', 'Tia Mulia', 'Teller', '2021-01-04 07:50:00', '2021-01-04 07:52:00', 'done', 1),
(51, 'TR106', 'Riza Rias', 'Teller', '2021-01-04 07:56:00', '2021-01-04 07:59:00', 'done', 1),
(52, 'TR107', 'Novita Mei', 'Teller', '2021-01-04 08:10:00', '2021-01-04 08:15:00', 'done', 1),
(53, 'TR108', 'Lailatul', 'Teller', '2021-01-04 08:20:00', '2021-01-04 08:25:00', 'done', 1),
(54, 'TR109', 'Miftakhul', 'Teller', '2021-01-04 08:28:00', '2021-01-04 08:30:00', 'done', 1),
(55, 'TR1010', 'Adiar', 'Teller', '2021-01-04 08:52:00', '2021-01-04 08:59:00', 'done', 1),
(56, 'TR1010', 'Rey', 'Teller', '2021-01-04 09:02:00', '2021-01-04 09:20:00', 'done', 1),
(57, 'TR1010', 'Sinta', 'Teller', '2021-01-04 09:48:00', '2021-01-04 09:59:00', 'done', 1),
(58, 'TR1010', 'Nana', 'Teller', '2021-01-04 10:10:00', '2021-01-04 10:14:00', 'done', 1),
(59, 'TR1010', 'Lin Luna', 'Teller', '2021-01-04 10:24:00', '2021-01-04 10:40:00', 'done', 1),
(60, 'TR1010', 'Jannah Jumatul', 'Teller', '2021-01-04 10:41:00', '2021-01-04 10:50:00', 'done', 1),
(61, 'TR1010', 'Coronavira', 'Teller', '2021-01-04 10:52:00', '2021-01-04 10:59:00', 'done', 1),
(62, 'TR1010', 'Vierranatasya', 'Teller', '2021-01-04 11:02:00', '2021-01-04 11:05:00', 'done', 1),
(63, 'TR1010', 'Adeeva Salsa', 'Teller', '2021-01-04 11:10:00', '2021-01-04 11:15:00', 'done', 1),
(64, 'TR1010', 'Alifah Salsabila', 'Teller', '2021-01-04 11:18:00', '2021-01-04 11:24:00', 'done', 1),
(65, 'TR1010', 'Cahya Eka', 'Teller', '2021-01-04 11:32:00', '2021-01-04 11:49:00', 'done', 1),
(66, 'TR1010', 'Dwi Nur Cahyo', 'Teller', '2021-01-04 11:50:00', '2021-01-04 11:59:00', 'done', 1),
(67, 'TR1010', 'Alysa Saufika Ananda', 'Teller', '2021-01-04 12:04:00', '2021-01-04 12:10:00', 'done', 1),
(68, 'TR1010', 'Nefa Maulidiah', 'Teller', '2021-01-04 12:15:00', '2021-01-04 12:20:00', 'done', 1),
(69, 'TR1010', 'Tini Ariantini', 'Teller', '2021-01-04 12:25:00', '2021-01-04 12:34:00', 'done', 1),
(70, 'TR1010', 'Ely Nur Rahayu', 'Teller', '2021-01-04 12:40:00', '2021-01-04 12:45:00', 'done', 1),
(71, 'TR1010', 'Ananda Bella Oktavia', 'Teller', '2021-01-04 12:52:00', '2021-01-04 12:59:00', 'done', 1),
(72, 'TR1010', 'Alysa Fira', 'Teller', '2021-01-04 13:30:00', '2021-01-04 13:40:00', 'done', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`id_transaction`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `id_transaction` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
